import { FooterApp } from './style'

export function Footer(){
    return(
        <FooterApp>
            <p>Projeto desenvolvido por: Coti Informática</p>
        </FooterApp>
    )
}