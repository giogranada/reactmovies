export default function Erro(){
    return(
        <h1>Página não encontrada.</h1>
    )
}