import { List } from "../../components/List";

export default function Filmes(){
    return(
        <List titulo='Filmes' subtitulo="O catálogo mais completo de obras cult e blockbusters." categoria='movie'/>
    )
}