import { List } from "../../components/List";

export default function Series(){
    return(
        <List titulo='Séries' subtitulo="As melhores séries e animações, de todos os lugares do mundo." categoria='tv'/>
    )
}